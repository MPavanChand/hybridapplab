package com.example.basic_calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    boolean isnewop = true;
    EditText screen;
    String oldnum = "0", op = "*";
    public void numberEvent(View v){
        if(isnewop){
            screen.setText("");
        }
        isnewop = false;
            String num = screen.getText().toString();
            switch (v.getId()){
                case R.id.one: num += "1"; break;
                case R.id.two: num += "2"; break;
                case R.id.three: num += "3"; break;
                case R.id.four: num += "4"; break;
                case R.id.five: num += "5"; break;
                case R.id.six: num += "6"; break;
                case R.id.seven: num += "7"; break;
                case R.id.eight: num += "8"; break;
                case R.id.nine: num += "9"; break;
                case R.id.zero: num += "0"; break;
                case R.id.dot: num += "."; break;
                case R.id.negative: num = "-" + num; break;
            }
            screen.setText(num);
    }
    public void operatorEvent(View v){
        isnewop = true;
        oldnum = screen.getText().toString();
        switch (v.getId()){
            case R.id.add: op = "+"; break;
            case R.id.subtract: op = "-"; break;
            case R.id.divide: op = "/"; break;
            case R.id.multiply: op = "*"; break;
        }
    }
    public void equalEvent(View v){
        String newNum = screen.getText().toString();
        double result = 0.0;
        switch (op){
            case "+":
                result = Double.parseDouble(oldnum) + Double.parseDouble(newNum);
                break;
            case "-":
                result = Double.parseDouble(oldnum) - Double.parseDouble(newNum);
                break;
            case "/":
                result = Double.parseDouble(oldnum) / Double.parseDouble(newNum);
                break;
            case "*":
                result = Double.parseDouble(oldnum) * Double.parseDouble(newNum);
                break;
        }
        screen.setText(Double.toString(result));
    }
    public void acEvent(View v){
        screen.setText("0");
        isnewop = true;
    }
    public void percentageEvent(View v){
        String num = screen.getText().toString();
        Double ans = Double.parseDouble(num);
        ans /= 100;
        screen.setText(Double.toString(ans));
        isnewop = true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        screen = findViewById(R.id.editext);
    }
}