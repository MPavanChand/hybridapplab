    package com.example.web_view_java;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

    public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView view = new WebView(this);
        view.getSettings().setJavaScriptEnabled(true);
        setContentView(view);
        view.loadUrl("file:///android_asset/demo.html");
    }
}